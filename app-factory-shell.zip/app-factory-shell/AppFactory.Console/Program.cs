﻿using AppFactory.Common.infrastructure;
using AppFactory.Services.Interface;
using AppFactory.Services.ShoppingCart;
using Autofac;
using System;

namespace AppFactory.Console
{
    class Program
    {
        static void Main(string[] args)
        {

            var builder = IocBootstrapper.RegisterModules();

            ILifetimeScope scope = builder.Build().BeginLifetimeScope();

            var customerService = scope.Resolve<ICustomerService>();

            var newCustomer = customerService.GetNewCustomer();

            newCustomer.Name = "LongLong";
        }
    }
}