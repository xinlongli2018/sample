﻿namespace AppFactory.Domain.Enum
{
    public enum Moods
    {
        Happy = 1,
        Neutral = 2,
        Sad = 3
    }
}
