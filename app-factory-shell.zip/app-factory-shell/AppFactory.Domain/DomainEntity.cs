﻿namespace AppFactory.Domain
{
    public abstract class DomainEntity
    {
        public int Id { get; set; }

        // todo: add CreateDate, UpdateDate later
    }
}
