﻿using AppFactory.Domain.Enum;

namespace AppFactory.Domain.Customers
{
    public class Customer : DomainEntity
    {
        public string Name { get; set; }

        public Moods Mood { get; set; }
    }
}
