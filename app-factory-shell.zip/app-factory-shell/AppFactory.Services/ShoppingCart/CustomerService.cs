﻿using AppFactory.Interface.Business;
using System.Collections.Generic;
using AppFactory.Domain.Customers;
using AppFactory.Interface.Data;
using System.Linq;

namespace AppFactory.Services.ShoppingCart
{
    public class CustomerService : ICustomerService
    {
        private readonly IRepository<Customer> _customerRepo;

        public CustomerService(IRepository<Customer> customerRepo)
        {
            _customerRepo = customerRepo;
        }

        public void AddCustomer(Customer newCustomer)
        {
            _customerRepo.Insert(newCustomer);
        }

        public Customer DeleteCustomer(int id)
        {
            var customer = _customerRepo.GetById(id);
            _customerRepo.Delete(customer);

            return customer;
        }

        public IList<Customer> GetAllCustomers()
        {
            return _customerRepo.GetAll().ToList();
        }

        public Customer GetCustomerById(int id)
        {
            return _customerRepo.GetById(id);
        }

        public Customer GetNewCustomer()
        {
            return new Customer();
        }

        public void UpdateCustomer(Customer customer)
        {
            _customerRepo.Update(customer);
        }
    }
}
