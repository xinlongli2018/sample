﻿using AppFactory.Common.Enums;
using AppFactory.Common.Infrastructure;
using AppFactory.Interface.Business;
using Autofac;
using System.Collections.Generic;

namespace AppFactory.Services.ShoppingCart
{
    public class ShoppingCartModule : ExtendedIocModule
    {
        public ShoppingCartModule(InstanceScopes scope) : base(scope) { }

        protected override List<object> GetRegistrar(ContainerBuilder builder)
        {
            var regs = new List<object>
            {
                builder.RegisterType<CustomerService>().As<ICustomerService>()
            };

            return regs;
        }
    }
}
