﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AppFactory.Common.Enums
{
    public enum InstanceScopes
    {
        SingleInstance,
        InstancePerLifetimeScope,
        InstancePerRequest
    }
}
