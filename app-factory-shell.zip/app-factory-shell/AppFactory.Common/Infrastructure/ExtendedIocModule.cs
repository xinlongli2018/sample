﻿using AppFactory.Common.Enums;
using Autofac;
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;

namespace AppFactory.Common.Infrastructure
{
    public abstract class ExtendedIocModule : Autofac.Module
    {
        private InstanceScopes _scope;
        public ExtendedIocModule(InstanceScopes scope)
        {

            _scope = scope;
        }

        abstract protected List<object> GetRegistrar(ContainerBuilder builder);

        protected override void Load(ContainerBuilder builder)
        {
            var regs = GetRegistrar(builder);

            foreach(var reg in regs)
            {
                Type type = reg.GetType();
                MethodInfo method = type.GetMethod(_scope.ToString());
                method.Invoke(reg, null);
            }

            base.Load(builder);
        }
    }
}
