﻿using AppFactory.Common.Enums;
using Autofac;
using Autofac.Core;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.Loader;

namespace AppFactory.Common.Infrastructure
{
    public static class IocBootstrapper
    {
        public static ContainerBuilder RegisterModules(ContainerBuilder containerBuilder = null, InstanceScopes scope = InstanceScopes.SingleInstance)
        {
            ContainerBuilder builder = containerBuilder ?? new ContainerBuilder();

            // get the path for the running app
            string path = Path.GetDirectoryName(Assembly.GetEntryAssembly().Location);

            if (!string.IsNullOrEmpty(path))
            {
                // get the dlls specfic for ShiftWise name space
                var assemblies = Directory.GetFiles(path, "AppFactory*.dll", SearchOption.TopDirectoryOnly)
                    .Select(i => AssemblyLoadContext.Default.LoadFromAssemblyName(AssemblyLoadContext.GetAssemblyName(i)))
                    .ToList();


                foreach (var assembly in assemblies)
                {
                    // reflect all the types that implement the autofac IModule and create an instance of it
                    var modules = assembly.GetTypes()
                                          .Where(p => typeof(IModule).IsAssignableFrom(p) && !p.GetTypeInfo().IsAbstract)
                                          .Select(p => (IModule)Activator.CreateInstance(p, new object[] { scope }));

                    // register the modules
                    foreach (var module in modules)
                    {
                        builder.RegisterModule(module);
                    }
                }
            }

            return builder;
        }
    }
}
