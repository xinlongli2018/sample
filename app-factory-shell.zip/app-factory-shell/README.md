# README #

All our frameworks and best practice patterns are encapsulated in this app-framework repo.