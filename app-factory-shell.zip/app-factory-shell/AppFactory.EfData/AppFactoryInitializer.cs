﻿using AppFactory.Domain.Customers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AppFactory.EfData
{
    public class AppFactoryInitializer
    {
        public static void Initialize(AppFactoryContext context)
        {
            context.Database.EnsureCreated();

            // Look for any customers.
            if (context.Customers.Any())
            {
                return;   // DB has been seeded
            }
            var customer = new Customer
            {
                Name = "LongLong",
                Mood = Domain.Enum.Moods.Happy
            };

            context.Customers.Add(customer);

            context.SaveChanges();
        }

    }
}
