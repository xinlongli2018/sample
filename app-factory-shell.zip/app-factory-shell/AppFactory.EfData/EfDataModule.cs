﻿using AppFactory.Common.Enums;
using AppFactory.Common.Infrastructure;
using AppFactory.Interface.Data;
using Autofac;
using System;
using System.Collections.Generic;
using System.Text;

namespace AppFactory.EfData
{
    public class EfDataModule : ExtendedIocModule
    {
        public EfDataModule(InstanceScopes scope) : base(scope) { }

        protected override List<object> GetRegistrar(ContainerBuilder builder)
        {
            var regs = new List<object>
            {
                 builder.RegisterGeneric(typeof(EfRepository<>)).As(typeof(IRepository<>))
            };

            return regs;
        }
    }
}
