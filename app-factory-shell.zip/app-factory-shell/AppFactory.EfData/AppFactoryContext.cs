﻿using AppFactory.Domain.Customers;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace AppFactory.EfData
{
    public class AppFactoryContext : DbContext
    {
        public AppFactoryContext(DbContextOptions<AppFactoryContext> options)
            : base(options)
        {
        }

        public DbSet<Customer> Customers { get; set; }
    }
}
