﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AppFactory.Domain.Customers;
using AppFactory.Interface.Business;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace AppFactory.WebApi.Controllers
{
    [Route("api/[controller]")]
    public class CustomersController : BaseController
    {
        private readonly ICustomerService _customerService;
        public CustomersController(ICustomerService customerService)
        {
            _customerService = customerService;
        }

        // GET: api/Customers
        [HttpGet]
        public IActionResult Get()
        {
            var result = _customerService.GetAllCustomers();
            return Ok(result);
        }

        // GET: api/Customers/5
        [HttpGet("{id}", Name = "Get")]
        public IActionResult Get(int id)
        {
            var result = _customerService.GetCustomerById(id);

            if (result != null)
            {
                return Ok(result);
            }
            else
            {
                return NotFound($"Cannot find customer with Id {id}.");
            }
        }

        // POST: api/Customers
        [HttpPost]
        public IActionResult Post([FromBody]Customer newCustomer)
        {
            _customerService.AddCustomer(newCustomer);
            return Ok(newCustomer);
        }

        // PUT: api/Customers
        [HttpPut]
        public IActionResult Put([FromBody]Customer customer)
        {
            _customerService.UpdateCustomer(customer);
            return Ok(customer);
        }

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var result = _customerService.DeleteCustomer(id);

            if (result != null)
            {
                return Ok(result);
            }
            else
            {
                return BadRequest($"Cannot find customer with {id}");
            }
        }
    }
}
