﻿using AppFactory.Domain;
using System;
using System.Collections.Generic;
using System.Text;

namespace AppFactory.Interface.Data
{
    public partial interface IRepository<T> where T : DomainEntity
    {
        T GetById(object id);

        IEnumerable<T> GetAll();

        void Insert(T entity);

        void Insert(IEnumerable<T> entities);

        void Update(T entity);

        void Update(IEnumerable<T> entities);

        void Delete(T entity);

        void Delete(IEnumerable<T> entities);
    }
}
