﻿using AppFactory.Domain.Customers;
using System;
using System.Collections.Generic;
using System.Text;

namespace AppFactory.Interface.Business
{
    public interface ICustomerService
    {
        Customer GetNewCustomer();
        Customer GetCustomerById(int id);
        IList<Customer> GetAllCustomers();
        void AddCustomer(Customer newCustomer);
        void UpdateCustomer(Customer customer);
        Customer DeleteCustomer(int id);        
    }
}
